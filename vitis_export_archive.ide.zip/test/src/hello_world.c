#include "xil_io.h"
#include "xil_printf.h"

#define gpio 0x40000000


void main ()
{

	while (1){
		Xil_Out32(gpio,0x0000000f);
		print("led on \n\r");
		usleep(1000000);
		Xil_Out32(gpio,0x00000000);
		usleep(1000000);
		print("led off \n\r");
	}




}
